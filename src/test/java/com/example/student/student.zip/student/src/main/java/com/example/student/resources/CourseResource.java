package com.example.student.resources;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.student.modal.Course;
import com.example.student.modal.Student;
import com.example.student.service.CourseService;

@RestController
@RequestMapping("course")
public class CourseResource {
	
	
	@Autowired
	private CourseService  courseService;

	@PostMapping
	public ResponseEntity<Course> add(Course course) {
		
		return ResponseEntity.ok(courseService.add(course));
	}

	@DeleteMapping
	public void delete(int courseId) {
		
		courseService.delete(courseId);
	}
	
	
	@GetMapping
	public ResponseEntity<List<Student>> getStudents(int courseId) {
		
		List<Student> students = courseService.getStudents(courseId);
		
		return ResponseEntity.ok(students);
		
		
		
	}
}
