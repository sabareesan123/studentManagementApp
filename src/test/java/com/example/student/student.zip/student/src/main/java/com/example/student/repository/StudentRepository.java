package com.example.student.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.student.modal.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	//List<Course> findByCourse_Id(Integer courseId)

}
