package com.example.student.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.student.modal.Course;
import com.example.student.modal.Student;
import com.example.student.repository.StudentRepository;
import com.example.student.service.StudentService;

public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student add(Student student) {
		
		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		
		return studentRepository.findAll();
	}

	@Override
	public List<Student> getStudentsByCourse(String course) {
		
	
		
		return null;
	}

	@Override
	public void allocateCourse(int studentId, List<Course> courses) {
		
		Optional<Student> optionalStudent = studentRepository.findById(studentId);
		Student student = optionalStudent.get();
		student.setCourses(courses);
		studentRepository.save(student);

	}

	@Override
	public void delete(int studentId) {
		

	}

}
