package com.example.student.service;

import java.util.List;

import com.example.student.modal.Course;
import com.example.student.modal.Student;

public interface StudentService {
	
	Student add(Student student);
	List<Student> getAllStudents();
	List<Student> getStudentsByCourse(String course);
	void allocateCourse(int studentId,List<Course> courses);
	void delete(int studentId);
	
	

}
