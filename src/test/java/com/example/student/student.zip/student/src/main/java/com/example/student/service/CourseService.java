package com.example.student.service;

import java.util.List;

import com.example.student.modal.Course;
import com.example.student.modal.Student;

public interface CourseService {
	
	Course add(Course course);
	void delete(int courseId);
	List<Student> getStudents(int courseId);

}
