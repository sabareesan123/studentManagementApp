package com.example.student.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.student.modal.Course;
import com.example.student.modal.Student;
import com.example.student.service.StudentService;

@RestController
@RequestMapping("student")
public class StudentResource {
	
	
	@Autowired
	private StudentService studentService;
	
	
	@PostMapping
	public ResponseEntity<Student> add(@RequestBody Student student)
	{
		return ResponseEntity.ok(studentService.add(student));
	}
	
	
	@GetMapping
	public ResponseEntity<List<Student>> getAllStudents()
	{
		return ResponseEntity.ok(studentService.getAllStudents());
	}
	
//	public ResponseEntity<List<Student>> getStudentsByCourse(String course)
//	{
//		
//	}
	@PostMapping("allocateCourse/{studentId}")
	public void allocateCourse(@PathVariable int studentId,@RequestBody List<Course> courses)
	{
		
	}
	
	
	@DeleteMapping("{studentId}")
	public void delete(int studentId)
	{
		studentService.delete(studentId);
	}
	
	
	

}
