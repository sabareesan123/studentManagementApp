package com.example.student.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.student.modal.Course;
import com.example.student.modal.Student;
import com.example.student.repository.CourseRepository;
import com.example.student.service.CourseService;


public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseRepository courseRepository;

	@Override
	public Course add(Course course) {
		
		return courseRepository.save(course);
	}

	@Override
	public void delete(int courseId) {
		
		courseRepository.deleteById(courseId);
		
		
	}
	
	@Override
	public List<Student> getStudents(int courseId) {
		
		Optional<Course> course = courseRepository.findById(courseId);
		
		return course.get().getStudents();
		
		
		
	}
	

	
	

	
	

}
